#!/bin/bash
# Add Helm chart repositories for Prometheus and Grafana
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

# Install Prometheus
helm install prometheus prometheus-community/prometheus
# Verify Prometheus pods are running
kubectl get pods

# Install Grafana
helm install grafana grafana/grafana
# Verify Grafana pods are running
kubectl get pods
