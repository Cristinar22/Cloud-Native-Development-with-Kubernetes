#!/bin/bash
# Add Helm chart repositories for EFK stack
helm repo add elastic https://helm.elastic.co
helm repo add fluent https://fluent.github.io/helm-charts
helm repo update

# Install Elasticsearch
helm install elasticsearch elastic/elasticsearch --set replicas=1

# Install Fluentd
helm install fluentd fluent/fluentd

# Install Kibana
helm install kibana elastic/kibana

# Verify EFK pods are running
kubectl get pods

# Port-forward Kibana service to access UI
kubectl port-forward <kibana-pod-name> 5601:5601
