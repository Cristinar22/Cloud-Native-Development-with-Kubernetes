#!/bin/bash
# Add Helm chart repository for Jaeger
helm repo add jaegertracing https://jaegertracing.github.io/helm-charts
helm repo update

# Install Jaeger
helm install jaeger jaegertracing/jaeger

# Port-forward Jaeger Query service to access UI
kubectl port-forward service/jaeger-query 16686:16686
