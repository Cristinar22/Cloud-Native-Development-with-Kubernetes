#!/bin/bash
# Verify Helm installation
helm version
