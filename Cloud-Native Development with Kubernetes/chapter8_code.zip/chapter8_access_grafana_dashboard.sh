#!/bin/bash
# Find the Grafana pod name
kubectl get pods

# Port-forward the Grafana service
kubectl port-forward <grafana-pod-name> 3000:3000

# Retrieve Grafana admin password
kubectl get secret --namespace default grafana -o jsonpath="{.data.admin-password}" | base64 --decode ; echo
