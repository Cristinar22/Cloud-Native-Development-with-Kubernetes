print("Hello, World from Cloud-Native App!")
