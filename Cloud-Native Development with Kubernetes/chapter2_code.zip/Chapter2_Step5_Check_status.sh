#!/bin/bash
# Check the status of the cluster nodes
kubectl get nodes