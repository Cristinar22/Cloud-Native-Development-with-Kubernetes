#!/bin/bash
# Create a Deployment
kubectl create deployment hello-minikube --image=kicbase/echo-server:1.0

# Expose the Deployment as a Service
kubectl expose deployment hello-minikube --type=NodePort --port=8080

# List Services to find the NodePort
kubectl get services

# Open the Service in a browser (Minikube will provide the URL)
minikube service hello-minikube