#!/bin/bash
# Scale the deployment to 3 replicas
kubectl scale deployment hello-minikube --replicas=3

# List pods to verify new replicas
kubectl get pods

# Delete a pod to see auto-replacement (replace <pod-name> with actual pod name)
kubectl delete pod <pod-name>