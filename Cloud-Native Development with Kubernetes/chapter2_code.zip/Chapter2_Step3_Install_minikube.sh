#!/bin/bash
# Install Minikube on Mac (using Homebrew)
brew install minikube

# Install Minikube on Linux
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube