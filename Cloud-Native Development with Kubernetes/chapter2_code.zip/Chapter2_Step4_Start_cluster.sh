#!/bin/bash
# Start a Minikube cluster
minikube start