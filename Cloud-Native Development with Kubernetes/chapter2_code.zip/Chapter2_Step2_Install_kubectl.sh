#!/bin/bash
# Check if kubectl is installed
kubectl version --client