#!/bin/bash
# Script to clean up all resources
kubectl delete -f k8s/
helm uninstall capstone
