#!/bin/bash
# Script to clone capstone project
git clone https://github.com/cloudnative-guides/capstone-demo.git
cd capstone-demo
