#!/bin/bash
trivy image postgres:13
