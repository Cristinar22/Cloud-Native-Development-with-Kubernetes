#!/bin/bash
# Install KEDA into the cluster using Helm
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda