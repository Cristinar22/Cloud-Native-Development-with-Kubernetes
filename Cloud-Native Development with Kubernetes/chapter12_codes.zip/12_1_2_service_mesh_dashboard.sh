#!/bin/bash
# Launch the Linkerd dashboard
linkerd dashboard