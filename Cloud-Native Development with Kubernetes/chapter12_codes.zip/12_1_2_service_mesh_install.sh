#!/bin/bash
# Install Linkerd CLI and set up for service mesh
curl -sL https://run.linkerd.io/install | sh
export PATH=$PATH:$HOME/.linkerd2/bin