#!/bin/bash
# Verify prerequisites and install Linkerd into the cluster
linkerd check --pre
linkerd install | kubectl apply -f -
linkerd check