#!/bin/bash
# Simulate a node failure by stopping a Minikube node
minikube stop