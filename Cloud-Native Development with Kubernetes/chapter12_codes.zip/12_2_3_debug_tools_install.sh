#!/bin/bash
# Install advanced debugging tools
brew install stern  # Stream logs from multiple pods
brew install derailed/k9s/k9s  # Install k9s terminal UI for Kubernetes

# Launch k9s for cluster management
k9s