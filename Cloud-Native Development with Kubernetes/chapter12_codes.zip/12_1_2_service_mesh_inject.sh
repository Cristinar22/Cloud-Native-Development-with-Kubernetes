#!/bin/bash
# Inject Linkerd sidecar into an existing deployment
kubectl get deploy  # Find your app deployment name
kubectl annotate deploy/<your-deployment> linkerd.io/inject=enabled
kubectl rollout restart deploy/<your-deployment>