kubectl apply -f configmap.yaml
kubectl apply -f secret.yaml
kubectl apply -f deployment.yaml
kubectl expose deployment bookstore-deployment --type=NodePort --port=5000
minikube service bookstore-deployment

# To update config on the fly:
# kubectl edit configmap bookstore-config
# kubectl rollout restart deployment bookstore-deployment
