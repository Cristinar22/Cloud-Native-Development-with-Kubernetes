kubectl apply -f configmap.yaml
kubectl get configmaps
kubectl describe configmap bookstore-config
