# On Linux/macOS
echo -n "supersecret123" | base64

# On Windows (PowerShell)
[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("supersecret123"))
